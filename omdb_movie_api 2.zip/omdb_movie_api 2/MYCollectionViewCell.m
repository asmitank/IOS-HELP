//
//  MYCollectionViewCell.m
//  omdb_movie_api
//
//  Created by tops on 4/8/16.
//  Copyright (c) 2016 viewc. All rights reserved.
//

#import "MYCollectionViewCell.h"

@implementation MYCollectionViewCell

@synthesize img_vw;

-(id)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self)
    {
         // Initialization code
    }
    return self;
}

@end
