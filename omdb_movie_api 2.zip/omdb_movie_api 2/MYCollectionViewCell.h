//
//  MYCollectionViewCell.h
//  omdb_movie_api
//
//  Created by tops on 4/8/16.
//  Copyright (c) 2016 viewc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MYCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UICollectionView *img_vw;



@end
